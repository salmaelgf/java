package controller;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class SceneManager {
    public static void switchTo(Stage stage, String fxmlFile) throws IOException {
        Parent root = FXMLLoader.load(SceneManager.class.getResource(fxmlFile));
        stage.setScene(new Scene(root));
        stage.show();
    }
}
