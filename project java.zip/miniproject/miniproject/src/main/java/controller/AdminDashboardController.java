package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class AdminDashboardController {

    public void Utilisateurs(ActionEvent event) {
        try {
            // Charger la vue ListeUtilisateurs
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/controller/views/ListeUtilisateursView.fxml"));
            Stage stage = new Stage();
            stage.setScene(new Scene(loader.load()));
            stage.setTitle("Gestion des Utilisateurs");
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void article(ActionEvent event) {
        try {
            // Charger la vue ListeUtilisateurs
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/controller/views/listearticle.fxml"));
            Stage stage = new Stage();
            stage.setScene(new Scene(loader.load()));
            stage.setTitle("Gestion des Utilisateurs");
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void listedemande(ActionEvent event) {
        try {
            // Charger la vue ListeUtilisateurs
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/controller/views/ListeDemandes.fxml"));
            Stage stage = new Stage();
            stage.setScene(new Scene(loader.load()));
            stage.setTitle("Gestion des Utilisateurs");
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deconnecter(ActionEvent event) {
        System.exit(0);  // Fermer l'application
    }

    public void rechercherDemande(ActionEvent actionEvent) {
    }

    public void supprimerDemande(ActionEvent actionEvent) {
    }

    public void modifierEtatDemande(ActionEvent actionEvent) {
    }
}
