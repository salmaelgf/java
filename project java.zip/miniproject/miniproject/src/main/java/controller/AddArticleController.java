package controller;

import Models.Article;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import jakarta.persistence.*;

import java.time.LocalDate;

public class AddArticleController {

    @FXML private TextField refField;
    @FXML private TextField descField;
    @FXML private TextField statusField;
    @FXML private DatePicker donationDatePicker;
    @FXML private TextField quantityField;
    @FXML private Button submitButton;

    // Removed connectedUser field

    // Constructor to initialize with connected user
    public AddArticleController() {}

    // Called to initialize the controller
    @FXML
    private void initialize() {
        submitButton.setOnAction(event -> handleFormSubmission());
    }

    // Handle form submission
    @FXML
    private void handleFormSubmission() {
        try {
            String reference = refField.getText();
            String description = descField.getText();
            String articleStatus = statusField.getText();
            LocalDate donationDate = donationDatePicker.getValue();
            String receiptQuantity = quantityField.getText();

            // Create the article and assign values
            Article article = new Article();
            article.setReference(reference);
            article.setDescription(description);
            article.setArticleStatus(articleStatus);
            article.setDonationDate(java.sql.Date.valueOf(donationDate)); // Convert LocalDate to java.sql.Date
            article.setReceiptQuantity(receiptQuantity);

            // Save the article to the database...
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("miniproject");
            EntityManager em = emf.createEntityManager();

            try {
                em.getTransaction().begin();
                em.persist(article); // Persist the article object
                em.getTransaction().commit();
                showAlert(Alert.AlertType.INFORMATION, "Succès", "L'article a été ajouté avec succès.");
            } catch (Exception e) {
                if (em.getTransaction().isActive()) {
                    em.getTransaction().rollback();
                }
                e.printStackTrace();
                showAlert(Alert.AlertType.ERROR, "Erreur", "Erreur lors de l'ajout: " + e.getMessage());
            } finally {
                em.close(); // Ensure that the EntityManager is closed
            }

            resetForm();

        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Erreur", "Erreur lors de l'ajout: " + e.getMessage());
        }
    }


    private void resetForm() {
        refField.clear();
        descField.clear();
        statusField.clear();
        donationDatePicker.setValue(null);
        quantityField.clear();
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
