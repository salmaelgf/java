package controller;

import DAO.UtilisateurDAO;
import Models.Utilisateur;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.List;
import java.util.Optional;

public class ListeUtilisateursController {

    @FXML
    private TableView<Utilisateur> tableViewUtilisateurs;

    @FXML
    private TableColumn<Utilisateur, String> colNomUtilisateur;

    @FXML
    private TableColumn<Utilisateur, String> colMotDePasse;

    @FXML
    private TableColumn<Utilisateur, String> colAutorisation;

    @FXML
    private TableColumn<Utilisateur, String> colAdresse;

    @FXML
    private TableColumn<Utilisateur, String> colEmail;

    @FXML
    private TableColumn<Utilisateur, String> colNumeroTelephone;

    private ObservableList<Utilisateur> utilisateursList;
    private UtilisateurDAO utilisateurDAO;

    public ListeUtilisateursController() {
        this.utilisateurDAO = new UtilisateurDAO(); // Vous pouvez injecter cette dépendance si nécessaire
    }

    @FXML
    public void initialize() {
        // Initialisation des colonnes
        colNomUtilisateur.setCellValueFactory(new PropertyValueFactory<>("nomUtilisateur"));
        colMotDePasse.setCellValueFactory(new PropertyValueFactory<>("motDePasse"));
        colAutorisation.setCellValueFactory(new PropertyValueFactory<>("autorisation"));
        colAdresse.setCellValueFactory(new PropertyValueFactory<>("adresse"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        colNumeroTelephone.setCellValueFactory(new PropertyValueFactory<>("numeroTelephone"));

        // Chargement des utilisateurs dans la TableView
        loadUtilisateurs();
    }

    private void loadUtilisateurs() {
        List<Utilisateur> utilisateurs = utilisateurDAO.listerTous();
        utilisateursList = FXCollections.observableArrayList(utilisateurs);
        tableViewUtilisateurs.setItems(utilisateursList);
    }

    @FXML
    public void modifierAutorisation() {
        Utilisateur utilisateurSelectionne = tableViewUtilisateurs.getSelectionModel().getSelectedItem();

        if (utilisateurSelectionne != null) {
            String nouvelleAutorisation = demanderNouvelleAutorisation();

            if (nouvelleAutorisation != null && !nouvelleAutorisation.isEmpty()) {
                utilisateurSelectionne.setAutorisation(nouvelleAutorisation);
                boolean estMisAJour = utilisateurDAO.mettreAJourUtilisateur(utilisateurSelectionne.getNomUtilisateur(), nouvelleAutorisation);

                if (estMisAJour) {
                    tableViewUtilisateurs.refresh();
                    showAlert(AlertType.INFORMATION, "Modification réussie", "L'autorisation a été modifiée avec succès.");
                } else {
                    showAlert(AlertType.ERROR, "Erreur", "Une erreur est survenue lors de la mise à jour de l'autorisation.");
                }
            }
        } else {
            showAlert(AlertType.ERROR, "Erreur", "Aucun utilisateur sélectionné.");
        }
    }

    private String demanderNouvelleAutorisation() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Modifier l'Autorisation");
        dialog.setHeaderText("Entrez la nouvelle autorisation :");
        dialog.setContentText("Nouvelle autorisation :");

        Optional<String> result = dialog.showAndWait();
        return result.orElse(null);  // Retourne la saisie ou null si l'utilisateur annule
    }

    private void showAlert(AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    public void ajouterUtilisateur() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Ajouter un Utilisateur");
        dialog.setHeaderText("Entrez les informations du nouvel utilisateur :");
        dialog.setContentText("Nom d'utilisateur :");

        Optional<String> result = dialog.showAndWait();

        if (result.isPresent() && !result.get().isEmpty()) {
            String nomUtilisateur = result.get();

            Utilisateur nouvelUtilisateur = new Utilisateur(
                    nomUtilisateur,
                    "motDePasseParDefaut",  // Vous pouvez ajouter des champs pour d'autres informations
                    "UTILISATEUR",          // Autorisation par défaut
                    "adresseParDefaut",
                    "emailParDefaut@mail.com",
                    "0000000000"
            );

            boolean estAjoute = utilisateurDAO.ajouterUtilisateur(nouvelUtilisateur);

            if (estAjoute) {
                utilisateursList.add(nouvelUtilisateur);
                tableViewUtilisateurs.refresh();
                showAlert(AlertType.INFORMATION, "Ajout réussi", "Le nouvel utilisateur a été ajouté avec succès.");
            } else {
                showAlert(AlertType.ERROR, "Erreur", "Une erreur est survenue lors de l'ajout de l'utilisateur.");
            }
        }
    }

    @FXML
    public void supprimerUtilisateur() {
        Utilisateur utilisateurSelectionne = tableViewUtilisateurs.getSelectionModel().getSelectedItem();

        if (utilisateurSelectionne != null) {
            Alert confirmationDialog = new Alert(Alert.AlertType.CONFIRMATION);
            confirmationDialog.setTitle("Confirmer la Suppression");
            confirmationDialog.setHeaderText("Êtes-vous sûr de vouloir supprimer cet utilisateur ?");
            confirmationDialog.setContentText("Utilisateur : " + utilisateurSelectionne.getNomUtilisateur());

            Optional<ButtonType> result = confirmationDialog.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                boolean estSupprime = utilisateurDAO.supprimerUtilisateur(utilisateurSelectionne.getNomUtilisateur());

                if (estSupprime) {
                    utilisateursList.remove(utilisateurSelectionne);
                    tableViewUtilisateurs.refresh();
                    showAlert(AlertType.INFORMATION, "Suppression réussie", "L'utilisateur a été supprimé avec succès.");
                } else {
                    showAlert(AlertType.ERROR, "Erreur", "Une erreur est survenue lors de la suppression de l'utilisateur.");
                }
            }
        } else {
            showAlert(AlertType.ERROR, "Erreur", "Aucun utilisateur sélectionné.");
        }
    }
}
