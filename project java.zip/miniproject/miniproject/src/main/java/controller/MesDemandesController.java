package controller;



import Models.Demande;
import Models.Utilisateur;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.List;

public class MesDemandesController {

    @FXML
    private TableView<Demande> demandeTable;

    @FXML
    private TableColumn<Demande, String> emailColumn;

    @FXML
    private TableColumn<Demande, String> etatColumn;

    @FXML
    private TableColumn<Demande, String> nomBeneficierColumn;

    @FXML
    private TableColumn<Demande, String> emailBeneficierColumn;

    @FXML
    private TableColumn<Demande, String> telephoneBeneficierColumn;

    private final EntityManagerFactory emf = Persistence.createEntityManagerFactory("miniproject");

    private Utilisateur connectedUser;

    public void setConnectedUser(Utilisateur user) {
        this.connectedUser = user;
        loadDemandes();
    }

    @FXML
    public void initialize() {
        // Set up table columns
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        etatColumn.setCellValueFactory(new PropertyValueFactory<>("etat"));
        nomBeneficierColumn.setCellValueFactory(new PropertyValueFactory<>("nomBeneficier"));
        emailBeneficierColumn.setCellValueFactory(new PropertyValueFactory<>("emailBeneficier"));
        telephoneBeneficierColumn.setCellValueFactory(new PropertyValueFactory<>("telephoneBeneficier"));
    }

    @FXML
    private void onRefreshClicked() {
        loadDemandes();
    }

    private void loadDemandes() {
        if (connectedUser == null) return;

        List<Demande> demandes = getDemandesByUtilisateur(connectedUser);
        ObservableList<Demande> demandeList = FXCollections.observableArrayList(demandes);
        demandeTable.setItems(demandeList);
    }

    private List<Demande> getDemandesByUtilisateur(Utilisateur utilisateur) {
        EntityManager em = emf.createEntityManager();
        try {
            TypedQuery<Demande> query = em.createQuery(
                    "SELECT d FROM Demande d WHERE d.utilisateur = :utilisateur", Demande.class);
            query.setParameter("utilisateur", utilisateur);
            return query.getResultList();
        } finally {
            em.close();
        }
    }
}
