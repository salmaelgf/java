package controller;

// ArticleController.java


import Models.Article;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import java.util.List;

public class ArticleController {

    @FXML
    private TableView<Article> articleTable;

    @FXML
    private TableColumn<Article, Integer> colArticleId;

    @FXML
    private TableColumn<Article, String> colReference;

    @FXML
    private TableColumn<Article, String> colDescription;

    @FXML
    private TableColumn<Article, String> colArticleStatus;

    @FXML
    private TableColumn<Article, String> colDonationDate;

    @FXML
    private TableColumn<Article, String> colReceiptQuantity;

    private EntityManagerFactory emf;

    public void initialize() {
        // Initialize EntityManagerFactory
        emf = Persistence.createEntityManagerFactory("miniproject");

        // Set up table columns
        colArticleId.setCellValueFactory(new PropertyValueFactory<>("articleId"));
        colReference.setCellValueFactory(new PropertyValueFactory<>("reference"));
        colDescription.setCellValueFactory(new PropertyValueFactory<>("description"));
        colArticleStatus.setCellValueFactory(new PropertyValueFactory<>("articleStatus"));
        colDonationDate.setCellValueFactory(new PropertyValueFactory<>("donationDate"));
        colReceiptQuantity.setCellValueFactory(new PropertyValueFactory<>("receiptQuantity"));

        // Load articles from the database
        loadArticles();
    }

    private void loadArticles() {
        EntityManager em = emf.createEntityManager();
        try {
            // Fetch articles from the database
            List<Article> articles = em.createQuery("SELECT a FROM Article a", Article.class).getResultList();

            // Convert list to ObservableList for TableView
            ObservableList<Article> articleList = FXCollections.observableArrayList(articles);

            // Set items in TableView
            articleTable.setItems(articleList);
        } finally {
            em.close();
        }
    }

    public void close() {
        if (emf != null) {
            emf.close();
        }
    }
}
