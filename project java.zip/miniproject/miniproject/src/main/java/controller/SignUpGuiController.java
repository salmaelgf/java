package controller;

import DAO.UtilisateurDAO;
import Models.Utilisateur;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class SignUpGuiController {

    // Références aux champs de texte et mot de passe dans la vue
    @FXML
    private TextField textUsername;
    @FXML
    private PasswordField textPassword;
    @FXML
    private PasswordField textConfirmPassword;
    @FXML
    private TextField textEmail;
    @FXML
    private TextField textAddress;
    @FXML
    private TextField textPhoneNumber;

    private UtilisateurDAO utilisateurDAO = new UtilisateurDAO(); // DAO pour interagir avec la base de données

    // Méthode appelée lors de l'inscription
    @FXML
    private void inscrireUtilisateur(ActionEvent event) {
        String username = textUsername.getText();
        String password = textPassword.getText();
        String confirmPassword = textConfirmPassword.getText();
        String email = textEmail.getText();
        String address = textAddress.getText();
        String phoneNumber = textPhoneNumber.getText();

        if (username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || email.isEmpty() || address.isEmpty() || phoneNumber.isEmpty()) {
            afficherMessage("Erreur", "Tous les champs doivent être remplis.", Alert.AlertType.ERROR);
            return;
        }

        if (!password.equals(confirmPassword)) {
            afficherMessage("Erreur", "Les mots de passe ne correspondent pas.", Alert.AlertType.ERROR);
            return;
        }

        if (utilisateurDAO.existeParNomUtilisateur(username)) {
            afficherMessage("Erreur", "Ce nom d'utilisateur est déjà utilisé.", Alert.AlertType.ERROR);
            return;
        }

        Utilisateur utilisateur = new Utilisateur(username, password, "Utilisateur", email, address, phoneNumber);
        utilisateurDAO.ajouter(utilisateur);

        afficherMessage("Succès", "Inscription réussie !", Alert.AlertType.INFORMATION);

        fermerFenetre(event);  // Close the window
    }

    private void afficherMessage(String titre, String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(titre);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Méthode pour fermer la fenêtre (appeler cette méthode quand l'utilisateur veut quitter)
    @FXML
    private void fermerFenetre(ActionEvent event) {
        // Fermer l'application ou la fenêtre
        System.exit(0);  // Si vous souhaitez fermer l'application après l'inscription
    }
}
