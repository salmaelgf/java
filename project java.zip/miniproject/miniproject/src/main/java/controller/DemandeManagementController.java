package controller;

import Models.Demande;
import Models.Utilisateur;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

public class DemandeManagementController {

    @FXML
    private TableView<Demande> tableDemande;

    @FXML
    private TableColumn<Demande, Long> colId;

    @FXML
    private TableColumn<Demande, String> colNom;

    @FXML
    private TableColumn<Demande, String> colTelephone;

    @FXML
    private TableColumn<Demande, String> colEmail;

    @FXML
    private TableColumn<Demande, String> colEtat;

    @FXML
    private TextField searchField;

    private ObservableList<Demande> demandes;
    private Utilisateur connectedUser;

    // This method should load all demands into the table
    public void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNom.setCellValueFactory(new PropertyValueFactory<>("nom"));
        colTelephone.setCellValueFactory(new PropertyValueFactory<>("telephone"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        colEtat.setCellValueFactory(new PropertyValueFactory<>("etat"));

        // Initialize table data (this can be replaced by actual database or service calls)
        demandes = FXCollections.observableArrayList(); // Add data to this list
        tableDemande.setItems(demandes);
    }

    @FXML
    void rechercherDemande(ActionEvent event) {
        String searchQuery = searchField.getText();
        // Search functionality here (filter based on searchQuery)
    }

    @FXML
    void supprimerDemande(ActionEvent event) {
        Demande selectedDemande = tableDemande.getSelectionModel().getSelectedItem();
        if (selectedDemande != null) {
            demandes.remove(selectedDemande); // Remove selected demand
            // Add additional logic to handle removal (e.g., from database)
        }
    }

    @FXML
    void modifierEtatDemande(ActionEvent event) {
        Demande selectedDemande = tableDemande.getSelectionModel().getSelectedItem();
        if (selectedDemande != null) {
            // Add logic to modify the state of the selected demand
        }
    }


}
