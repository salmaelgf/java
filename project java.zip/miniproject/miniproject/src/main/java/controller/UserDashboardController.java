package controller;

import Models.Utilisateur;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import lombok.Setter;

import java.io.IOException;

@Setter
public class UserDashboardController {

    private Utilisateur connectedUser;

    @FXML
    private BorderPane mainPane;
    @FXML
    private VBox mainContent;
    @FXML
    private PieChart donationsPieChart;
    @FXML
    private BarChart<String, Number> monthlyDonationsBarChart;
    @FXML
    private CategoryAxis xAxis;

    @FXML
    public void initialize() {
        // Initialize PieChart data
        donationsPieChart.getData().addAll(
                new PieChart.Data("Food", 40),
                new PieChart.Data("Clothes", 30),
                new PieChart.Data("Money", 20),
                new PieChart.Data("Others", 10)
        );

        // Initialize BarChart data
        xAxis.setCategories(FXCollections.observableArrayList(
                "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
        ));

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.getData().add(new XYChart.Data<>("Jan", 50));
        series.getData().add(new XYChart.Data<>("Feb", 80));
        series.getData().add(new XYChart.Data<>("Mar", 60));
        series.getData().add(new XYChart.Data<>("Apr", 70));
        series.getData().add(new XYChart.Data<>("May", 90));
        series.getData().add(new XYChart.Data<>("Jun", 100));
        series.getData().add(new XYChart.Data<>("Jul", 110));
        series.getData().add(new XYChart.Data<>("Aug", 120));
        series.getData().add(new XYChart.Data<>("Sep", 130));
        series.getData().add(new XYChart.Data<>("Oct", 140));
        series.getData().add(new XYChart.Data<>("Nov", 150));
        series.getData().add(new XYChart.Data<>("Dec", 160));

        monthlyDonationsBarChart.getData().add(series);
    }

    @FXML
    private void showAddArticle() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/controller/views/add_article.fxml"));
            Node addArticleNode = loader.load();
            mainPane.setCenter(addArticleNode);
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de charger l'interface Ajouter Article.");
        }
    }

    @FXML
    private void showAddDemande() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/controller/views/AjouterDemande.fxml"));
            Node addDemandeView = loader.load();
            mainPane.setCenter(addDemandeView);
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de charger l'interface Ajouter Demande.");
        }
    }

    @FXML
    private void showAddDonateur() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/controller/views/donateur_form.fxml"));
            Node addDonateurNode = loader.load();
            mainPane.setCenter(addDonateurNode);
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de charger l'interface Ajouter Donateur.");
        }
    }

    @FXML
    public void deconnecter(ActionEvent event) {
        System.exit(0); // Close the application
    }

    private void showAlert(Alert.AlertType alertType, String title, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}