package controller;

import Models.Donateur;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import java.util.Date;

public class DonateurController {

    private EntityManagerFactory emf;
    private EntityManager em;

    @FXML private TextField nameField;
    @FXML private TextField emailField;
    @FXML private TextField telField;
    @FXML private ComboBox<String> typeDonCombo;
    @FXML private TextField quantiteField;
    @FXML private TextArea descriptionField;
    @FXML private Label dateCreationLabel;

    @FXML
    public void initialize() {
        Date currentDate = new Date();
        dateCreationLabel.setText(currentDate.toString());

        emf = Persistence.createEntityManagerFactory("miniproject");
        em = emf.createEntityManager();
    }

    @FXML
    private void handleSubmit() {
        String name = nameField.getText();
        String email = emailField.getText();
        String tel = telField.getText();
        String typeDon = typeDonCombo.getValue();
        if (typeDon == null || typeDon.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Invalid Input", "Please select a type of donation.");
            return;
        }
        int quantite;
        try {
            quantite = Integer.parseInt(quantiteField.getText());
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Invalid Input", "Please enter a valid quantity.");
            return;
        }
        String description = descriptionField.getText();

        Donateur donateur = new Donateur(name, email, tel, typeDon, quantite, description);

        try {
            em.getTransaction().begin();
            em.persist(donateur);
            em.getTransaction().commit();
            showAlert(Alert.AlertType.INFORMATION, "Success", "Donateur saved successfully!");
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Error", "An error occurred while saving the donateur.");
        }

        nameField.clear();
        emailField.clear();
        telField.clear();
        typeDonCombo.getSelectionModel().clearSelection();
        quantiteField.clear();
        descriptionField.clear();
    }

    public void close() {
        if (em != null && em.isOpen()) {
            em.close();
        }
        if (emf != null) {
            emf.close();
        }
    }

    private void showAlert(Alert.AlertType alertType, String title, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}