package controller;

import DAO.DemandeDAO;
import Models.Demande;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.List;

public class ListeDemandesController {

    @FXML
    private TableView<Demande> tableViewDemandes;

    @FXML
    private TableColumn<Demande, Long> colId;

    @FXML
    private TableColumn<Demande, String> colEmail;

    @FXML
    private TableColumn<Demande, String> colEtat;

    @FXML
    private TableColumn<Demande, String> colNomBeneficier;

    @FXML
    private TableColumn<Demande, String> colEmailBeneficier;

    @FXML
    private TableColumn<Demande, String> colTelephoneBeneficier;

    @FXML
    private TableColumn<Demande, String> colDateCreation;

    private ObservableList<Demande> demandesList;
    private DemandeDAO demandeDAO;

    public ListeDemandesController() {
        this.demandeDAO = new DemandeDAO(); // Initialisation du DAO
    }

    @FXML
    public void initialize() {
        // Configuration des colonnes
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        colEtat.setCellValueFactory(new PropertyValueFactory<>("etat"));
        colNomBeneficier.setCellValueFactory(new PropertyValueFactory<>("nomBeneficier"));
        colEmailBeneficier.setCellValueFactory(new PropertyValueFactory<>("emailBeneficier"));
        colTelephoneBeneficier.setCellValueFactory(new PropertyValueFactory<>("telephoneBeneficier"));
        colDateCreation.setCellValueFactory(new PropertyValueFactory<>("dateCreation"));

        // Charger les demandes dans le TableView
        loadDemandes();
    }

    private void loadDemandes() {
        List<Demande> demandes = demandeDAO.listerTous();
        demandesList = FXCollections.observableArrayList(demandes);
        tableViewDemandes.setItems(demandesList);
    }

    @FXML
    public void accepterDemande() {
        Demande demandeSelectionnee = tableViewDemandes.getSelectionModel().getSelectedItem();

        if (demandeSelectionnee != null) {
            boolean estAcceptee = demandeDAO.accepterDemande(Math.toIntExact(demandeSelectionnee.getId()));

            if (estAcceptee) {
                demandeSelectionnee.setEtat("Acceptée");
                tableViewDemandes.refresh();
                showAlert(AlertType.INFORMATION, "Demande Acceptée", "La demande a été acceptée avec succès.");
            } else {
                showAlert(AlertType.ERROR, "Erreur", "Une erreur est survenue lors de l'acceptation de la demande.");
            }
        } else {
            showAlert(AlertType.ERROR, "Erreur", "Aucune demande sélectionnée.");
        }
    }

    @FXML
    public void refuserDemande() {
        Demande demandeSelectionnee = tableViewDemandes.getSelectionModel().getSelectedItem();

        if (demandeSelectionnee != null) {
            boolean estRefusee = demandeDAO.refuserDemande(Math.toIntExact(demandeSelectionnee.getId()));

            if (estRefusee) {
                demandeSelectionnee.setEtat("Refusée");
                tableViewDemandes.refresh();
                showAlert(AlertType.INFORMATION, "Demande Refusée", "La demande a été refusée avec succès.");
            } else {
                showAlert(AlertType.ERROR, "Erreur", "Une erreur est survenue lors du refus de la demande.");
            }
        } else {
            showAlert(AlertType.ERROR, "Erreur", "Aucune demande sélectionnée.");
        }
    }

    private void showAlert(AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
