package controller;

import Models.Demande;
import jakarta.persistence.*;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.time.LocalDate;

public class DemandeController {

    @FXML
    private TextField emailField;

    @FXML
    private TextField nomBeneficierField;

    @FXML
    private TextField emailBeneficierField;

    @FXML
    private TextField telephoneBeneficierField;

    @FXML
    private Label dateCreationLabel;

    @FXML
    private Button submitButton;

    @FXML
    private Label statusLabel;

    private EntityManagerFactory emf;
    private EntityManager em;

    // Constructor for controller - only used for dependency injection in certain frameworks
    public DemandeController() {
        // You can leave it empty, or initialize resources like an EntityManager if required.
    }

    @FXML
    public void initialize() {
        // Initialize dateCreation with current date
        LocalDate currentDate = LocalDate.now();
        dateCreationLabel.setText(currentDate.toString());

        // Initialize EntityManager (JPA connection)
        emf = Persistence.createEntityManagerFactory("miniproject");
        em = emf.createEntityManager();
    }

    @FXML
    private void handleSubmission() {
        // Logic for handling the form submission
        String email = emailField.getText();
        String nomBeneficier = nomBeneficierField.getText();
        String emailBeneficier = emailBeneficierField.getText();
        String telephoneBeneficier = telephoneBeneficierField.getText();
        LocalDate currentDate = LocalDate.now();

        // Validation logic
        if (email.isEmpty() || nomBeneficier.isEmpty() || emailBeneficier.isEmpty() || telephoneBeneficier.isEmpty()) {
            statusLabel.setText("Veuillez remplir tous les champs obligatoires !");
        } else {
            Demande demande = new Demande(email, nomBeneficier, emailBeneficier, telephoneBeneficier);

            try {
                em.getTransaction().begin();
                em.persist(demande);
                em.getTransaction().commit();
                statusLabel.setText("Demande ajoutée avec succès à la date : " + currentDate);
            } catch (Exception e) {
                em.getTransaction().rollback();
                statusLabel.setText("Erreur lors de l'ajout de la demande.");
                e.printStackTrace();
            }
        }
    }

    public void cleanup() {
        if (em != null) {
            em.close();
        }
        if (emf != null) {
            emf.close();
        }
    }
}