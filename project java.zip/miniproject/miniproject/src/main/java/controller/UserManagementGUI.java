package controller;

import DAO.UtilisateurDAO;
import Models.Utilisateur;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.util.List;

public class UserManagementGUI extends Application {
    private UtilisateurDAO utilisateurDAO;
    private TableView<Utilisateur> table;
    private TextField textSearch;

    @Override
    public void start(Stage primaryStage) {
        utilisateurDAO = new UtilisateurDAO(); // Initialisation du DAO
        primaryStage.setTitle("Gestion des utilisateurs");

        // TableView pour afficher les utilisateurs
        table = new TableView<>();
        TableColumn<Utilisateur, Integer> colId = new TableColumn<>("ID");
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));

        TableColumn<Utilisateur, String> colNomUtilisateur = new TableColumn<>("Nom d'utilisateur");
        colNomUtilisateur.setCellValueFactory(new PropertyValueFactory<>("nomUtilisateur"));

        TableColumn<Utilisateur, String> colMotDePasse = new TableColumn<>("Mot de passe");
        colMotDePasse.setCellValueFactory(new PropertyValueFactory<>("motDePasse"));

        TableColumn<Utilisateur, String> colAutorisation = new TableColumn<>("Autorisation");
        colAutorisation.setCellValueFactory(new PropertyValueFactory<>("autorisation"));

        TableColumn<Utilisateur, String> colAdresse = new TableColumn<>("Adresse");
        colAdresse.setCellValueFactory(new PropertyValueFactory<>("adresse"));

        TableColumn<Utilisateur, String> colEmail = new TableColumn<>("Email");
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));

        TableColumn<Utilisateur, String> colTelephone = new TableColumn<>("Téléphone");
        colTelephone.setCellValueFactory(new PropertyValueFactory<>("numeroTelephone"));

        table.getColumns().addAll(colId, colNomUtilisateur, colMotDePasse, colAutorisation, colAdresse, colEmail, colTelephone);

        // Charger les utilisateurs
        chargerUtilisateurs();

        // Barre de recherche et boutons d'action
        textSearch = new TextField();
        textSearch.setPromptText("Rechercher un utilisateur");
        Button btnSearch = new Button("Rechercher");
        Button btnAdd = new Button("Ajouter");
        Button btnDelete = new Button("Supprimer");
        Button btnUpdateRole = new Button("Modifier Autorisation");

        HBox actionBox = new HBox(10, textSearch, btnSearch, btnAdd, btnDelete, btnUpdateRole);
        actionBox.setPadding(new Insets(10));

        // Actions des boutons
        btnSearch.setOnAction(event -> rechercherUtilisateur());
        btnAdd.setOnAction(event -> ajouterUtilisateur());
        btnDelete.setOnAction(event -> supprimerUtilisateur());
        btnUpdateRole.setOnAction(event -> modifierAutorisationUtilisateur());

        // Mise en page principale
        BorderPane root = new BorderPane();
        root.setTop(actionBox);
        root.setCenter(table);

        Scene scene = new Scene(root, 900, 500);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void chargerUtilisateurs() {
        List<Utilisateur> utilisateurs = utilisateurDAO.listerTous();
        ObservableList<Utilisateur> utilisateursData = FXCollections.observableArrayList(utilisateurs);
        table.setItems(utilisateursData);
    }

    private void ajouterUtilisateur() {
        // Vous pouvez ouvrir une fenêtre ou une boîte de dialogue pour ajouter un utilisateur
        // Voici un exemple simple, vous pouvez l'adapter selon vos besoins
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Ajouter un utilisateur");
        dialog.setHeaderText("Entrez le nom d'utilisateur");
        dialog.setContentText("Nom d'utilisateur:");

        dialog.showAndWait().ifPresent(username -> {
            // Pour l'exemple, nous demandons ici uniquement le nom d'utilisateur
            // Vous pouvez étendre cela pour demander tous les autres champs nécessaires
            Utilisateur utilisateur = new Utilisateur(username, "password", "Utilisateur", "email", "adresse", "123456");
            utilisateurDAO.ajouter(utilisateur);
            chargerUtilisateurs(); // Recharger les utilisateurs après ajout
            afficherMessage("Succès", "Utilisateur ajouté !");
        });
    }

    private void supprimerUtilisateur() {
        Utilisateur selectedUser = table.getSelectionModel().getSelectedItem();
        if (selectedUser != null) {
            boolean success = utilisateurDAO.supprimerParId(String.valueOf(selectedUser.getId()));
            if (success) {
                chargerUtilisateurs(); // Recharger les utilisateurs après suppression
                afficherMessage("Succès", "Utilisateur supprimé !");
            } else {
                afficherMessage("Erreur", "Impossible de supprimer l'utilisateur.");
            }
        } else {
            afficherMessage("Erreur", "Veuillez sélectionner un utilisateur.");
        }
    }

    private void rechercherUtilisateur() {
        String searchQuery = textSearch.getText().toLowerCase();
        List<Utilisateur> utilisateurs = utilisateurDAO.listerTous();
        ObservableList<Utilisateur> filteredList = FXCollections.observableArrayList();

        for (Utilisateur utilisateur : utilisateurs) {
            if (utilisateur.getNomUtilisateur().toLowerCase().contains(searchQuery)) {
                filteredList.add(utilisateur);
            }
        }

        table.setItems(filteredList);
    }

    private void modifierAutorisationUtilisateur() {
        Utilisateur selectedUser = table.getSelectionModel().getSelectedItem();
        if (selectedUser != null) {
            // Create a dialog to modify the authorization
            TextInputDialog dialog = new TextInputDialog(selectedUser.getAutorisation());
            dialog.setTitle("Modifier Autorisation");
            dialog.setHeaderText("Modifiez l'autorisation de l'utilisateur");
            dialog.setContentText("Autorisation:");

            dialog.showAndWait().ifPresent(newRole -> {
                // Update the authorization in the database
                boolean success = utilisateurDAO.modifierUtilisateur(
                        String.valueOf(selectedUser.getId()),
                        selectedUser.getNomUtilisateur(),
                        selectedUser.getMotDePasse(),
                        newRole,
                        selectedUser.getAdresse(),
                        selectedUser.getEmail(),
                        selectedUser.getNumeroTelephone()
                );

                if (success) {
                    // Update the authorization in the selected user object
                    selectedUser.setAutorisation(newRole);

                    // Since autorisation is a StringProperty, the TableView will automatically update
                    afficherMessage("Succès", "Autorisation mise à jour !");
                } else {
                    afficherMessage("Erreur", "Erreur lors de la mise à jour de l'autorisation.");
                }
            });
        } else {
            afficherMessage("Erreur", "Veuillez sélectionner un utilisateur.");
        }
    }



    private void afficherMessage(String titre, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titre);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
