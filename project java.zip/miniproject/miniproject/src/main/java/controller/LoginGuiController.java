package controller;

import DAO.UtilisateurDAO;
import Models.Utilisateur;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;

public class LoginGuiController {

    @FXML
    private TextField textUsername;
    @FXML
    private PasswordField textPassword;

    private UtilisateurDAO utilisateurDAO = new UtilisateurDAO();

    @FXML
    private void connecterUtilisateur(ActionEvent event) {
        String username = textUsername.getText();
        String password = textPassword.getText();


        Utilisateur utilisateur = utilisateurDAO.verifierIdentifiants(username, password);

        if (utilisateur != null) {

            try {
                FXMLLoader loader;
                Parent root;
                String role = utilisateur.getAutorisation();


                if ("admin".equalsIgnoreCase(role)) {

                    loader = new FXMLLoader(getClass().getResource("/controller/views/AdminDashboard.fxml"));
                } else {

                    loader = new FXMLLoader(getClass().getResource("/controller/views/UserDashboard.fxml"));
                }

                root = loader.load();
                Scene scene = new Scene(root);
                Stage stage = (Stage) textUsername.getScene().getWindow(); // Récupérer la fenêtre actuelle
                stage.setScene(scene);
                stage.setTitle(role.equalsIgnoreCase("admin") ? "Admin Dashboard" : "User Dashboard");
                stage.show();

            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            // Afficher une alerte en cas d'échec de connexion
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Login Failed");
            alert.setHeaderText("Invalid Credentials");
            alert.setContentText("Please check your username and password.");
            alert.showAndWait();
        }
    }

    @FXML
    private void fermerFenetre(ActionEvent event) {
        System.exit(0); // Fermer l'application
    }
}
