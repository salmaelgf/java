package controller;



import Models.Demande;
import jakarta.persistence.*;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.util.List;

public class GestionDemandesGUI extends Application {

    private TableView<Demande> table;
    private EntityManagerFactory emf;

    @Override
    public void start(Stage primaryStage) {
        emf = Persistence.createEntityManagerFactory("miniproject"); // Initialize EntityManagerFactory
        primaryStage.setTitle("Gestion des demandes");

        // Create TableView to display demands
        table = new TableView<>();
        TableColumn<Demande, Long> colId = new TableColumn<>("ID");
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));

        TableColumn<Demande, String> colNom = new TableColumn<>("Nom");
        colNom.setCellValueFactory(new PropertyValueFactory<>("nom"));

        TableColumn<Demande, String> colTelephone = new TableColumn<>("Téléphone");
        colTelephone.setCellValueFactory(new PropertyValueFactory<>("telephone"));

        TableColumn<Demande, String> colEmail = new TableColumn<>("Email");
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));

        TableColumn<Demande, String> colEtat = new TableColumn<>("État");
        colEtat.setCellValueFactory(new PropertyValueFactory<>("etat"));

        TableColumn<Demande, String> colCategory = new TableColumn<>("Catégorie");
        colCategory.setCellValueFactory(new PropertyValueFactory<>("category"));

        TableColumn<Demande, String> colDateCreation = new TableColumn<>("Date de Création");
        colDateCreation.setCellValueFactory(new PropertyValueFactory<>("dateCreation"));

        table.getColumns().addAll(colId, colNom, colTelephone, colEmail, colEtat, colCategory, colDateCreation);

        // Load the demands into the TableView
        loadDemands();

        // Add controls for interaction
        Button btnRefresh = new Button("Rafraîchir");
        btnRefresh.setOnAction(event -> loadDemands());

        Button btnDelete = new Button("Supprimer");
        btnDelete.setOnAction(event -> deleteSelectedDemand());

        HBox actionBox = new HBox(10, btnRefresh, btnDelete);
        actionBox.setPadding(new Insets(10));

        // Main layout
        BorderPane root = new BorderPane();
        root.setCenter(table);
        root.setBottom(actionBox);

        Scene scene = new Scene(root, 900, 500);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * Load all demands from the database into the TableView
     */
    private void loadDemands() {
        EntityManager em = emf.createEntityManager();
        try {
            String query = "SELECT d FROM Demande d";
            TypedQuery<Demande> typedQuery = em.createQuery(query, Demande.class);
            List<Demande> demandes = typedQuery.getResultList();

            ObservableList<Demande> demandesData = FXCollections.observableArrayList(demandes);
            table.setItems(demandesData);
        } catch (Exception e) {
            showAlert("Erreur", "Erreur lors du chargement des demandes : " + e.getMessage());
        } finally {
            em.close();
        }
    }

    /**
     * Delete the selected demand from the table and database
     */
    private void deleteSelectedDemand() {
        Demande selectedDemande = table.getSelectionModel().getSelectedItem();
        if (selectedDemande == null) {
            showAlert("Erreur", "Veuillez sélectionner une demande à supprimer.");
            return;
        }

        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            Demande demande = em.find(Demande.class, selectedDemande.getId());
            if (demande != null) {
                em.remove(demande);
            }
            em.getTransaction().commit();

            loadDemands();
            showAlert("Succès", "Demande supprimée avec succès !");
        } catch (Exception e) {
            em.getTransaction().rollback();
            showAlert("Erreur", "Erreur lors de la suppression de la demande : " + e.getMessage());
        } finally {
            em.close();
        }
    }

    /**
     * Show an alert dialog
     */
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
