package myapp;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class MainApp extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        // Load the FXML file for the login page
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/controller/views/MainGui.fxml"));
        GridPane root = loader.load();  // Load the interface of the login page

        // Create the scene and associate it with the main window
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Login Page");  // Set the window title
        primaryStage.show();  // Display the window
    }
}

