module miniproject {
    requires jakarta.persistence;
    requires javafx.controls;
    requires javafx.graphics;
    requires static lombok;
    requires javafx.fxml;

    // Pour JPA
    requires org.hibernate.orm.core; // Hibernate ORM
    requires java.sql;
    requires jdk.jfr;
    requires jdk.jconsole;
    requires mysql.connector.j;
    requires java.persistence; // JDBC

    exports myapp;
    exports controller;
    exports DAO;

    exports Models;
    opens Models to org.hibernate.orm.core;
    opens controller to javafx.fxml;



}