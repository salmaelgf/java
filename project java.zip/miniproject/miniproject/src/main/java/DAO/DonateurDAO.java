package DAO;

import Models.Donateur;

import java.util.List;

public interface DonateurDAO {
    void ajouterDonateur(Donateur donateur);
    Donateur obtenirDonateurParId(String id);
    void mettreAJourDonateur(Donateur donateur);
    void supprimerDonateur(String id);
    List<Donateur> obtenirTousLesDonateurs();
}