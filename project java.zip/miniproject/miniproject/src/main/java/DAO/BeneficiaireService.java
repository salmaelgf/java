package DAO;

import Models.Beneficiaire;

import java.util.List;

public interface BeneficiaireService {
    void ajouterBeneficiaire(Beneficiaire beneficiaire);
    Beneficiaire consulterBeneficiaire(String id);
    void modifierBeneficiaire(Beneficiaire beneficiaire);
    void supprimerBeneficiaire(Beneficiaire beneficiaire);
    List<Beneficiaire> listerTousBeneficiaires();
}
