package DAO;

import Models.Demande;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;

import java.util.List;

public class DemandeDAO {
    private EntityManager em;

    public DemandeDAO() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("miniproject");
        em = emf.createEntityManager();
    }

    public List<Demande> listerTous() {
        String jpql = "SELECT d FROM Demande d";
        TypedQuery<Demande> query = em.createQuery(jpql, Demande.class);
        return query.getResultList();
    }

    public boolean accepterDemande(int id) {
        return modifierStatutDemande(id, "Acceptée");
    }

    public boolean refuserDemande(int id) {
        return modifierStatutDemande(id, "Refusée");
    }

    private boolean modifierStatutDemande(int id, String nouveauStatut) {
        em.getTransaction().begin();
        try {
            Demande demande = em.find(Demande.class, id);
            if (demande != null) {
                demande.setStatut(nouveauStatut);
                em.getTransaction().commit();
                return true;
            }
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
        }
        return false;
    }
}
