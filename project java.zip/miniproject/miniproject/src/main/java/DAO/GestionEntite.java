package DAO;

import java.util.List;

public interface GestionEntite<T> {
    void ajouter(T entite);
    void supprimer(String id);
    void modifier(T entite);
    T consulter(String id);
    List<T> consulterTous();
}
