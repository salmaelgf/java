package DAO;

import jakarta.persistence.*;
import Models.Utilisateur;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import static com.mysql.cj.conf.PropertyKey.PASSWORD;
import static java.sql.DriverManager.getConnection;
import static org.hibernate.cfg.JdbcSettings.URL;
import static org.hibernate.cfg.JdbcSettings.USER;

public class UtilisateurDAO implements IUtilisateurDAO {
    private EntityManager em;

    // Initialisation de l'EntityManager
    public UtilisateurDAO() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("miniproject");
        em = emf.createEntityManager();
    }

    // Ajouter un utilisateur
    @Override
    // Ajouter un utilisateur

    public void ajouter(Utilisateur utilisateur) {
        executeTransaction(() -> em.persist(utilisateur));
    }


    // Trouver un utilisateur par nom d'utilisateur
    @Override
    public Utilisateur trouverParNomUtilisateur(String nomUtilisateur) {
        String jpql = "SELECT u FROM Utilisateur u WHERE u.nomUtilisateur = :nomUtilisateur";
        TypedQuery<Utilisateur> query = em.createQuery(jpql, Utilisateur.class);
        query.setParameter("nomUtilisateur", nomUtilisateur);

        return query.getResultStream().findFirst().orElse(null);
    }

    // Vérifier si un utilisateur existe par nom d'utilisateur
    @Override
    public boolean existeParNomUtilisateur(String nomUtilisateur) {
        return trouverParNomUtilisateur(nomUtilisateur) != null;
    }

    // Supprimer un utilisateur par nom d'utilisateur
    @Override
    public boolean supprimerParNomUtilisateur(String nomUtilisateur) {
        Utilisateur utilisateur = trouverParNomUtilisateur(nomUtilisateur);
        if (utilisateur != null) {
            executeTransaction(() -> em.remove(utilisateur));
            return true;
        }
        return false;
    }

    // Supprimer un utilisateur par ID
    @Override
    public boolean supprimerParId(String id) {
        Utilisateur utilisateur = em.find(Utilisateur.class, id);
        if (utilisateur != null) {
            executeTransaction(() -> em.remove(utilisateur));
            return true;
        }
        return false;
    }

    // Modifier un utilisateur
    @Override
    public boolean modifierUtilisateur(String id, String nouveauNomUtilisateur, String nouveauMotDePasse, String nouveauRole, String nouvelleAdresse, String nouvelEmail, String nouveauNumeroTelephone) {
        Utilisateur utilisateur = em.find(Utilisateur.class, id);
        if (utilisateur != null) {
            executeTransaction(() -> {
                utilisateur.setNomUtilisateur(nouveauNomUtilisateur);
                utilisateur.setMotDePasse(nouveauMotDePasse);
                utilisateur.setRole(nouveauRole);
                utilisateur.setAdresse(nouvelleAdresse);
                utilisateur.setEmail(nouvelEmail);
                utilisateur.setNumeroTelephone(nouveauNumeroTelephone);
            });
            return true;
        }
        return false;
    }

    // Lister tous les utilisateurs
    @Override
    public List<Utilisateur> listerTous() {
        String jpql = "SELECT u FROM Utilisateur u";
        TypedQuery<Utilisateur> query = em.createQuery(jpql, Utilisateur.class);
        return query.getResultList();
    }

    // Vérifier les identifiants
    public boolean verifierConnexion(String username, String password) {
        String jpql = "SELECT u FROM Utilisateur u WHERE u.nomUtilisateur = :username AND u.motDePasse = :password";
        TypedQuery<Utilisateur> query = em.createQuery(jpql, Utilisateur.class);
        query.setParameter("username", username);
        query.setParameter("password", password);

        return query.getResultStream().findFirst().isPresent();
    }

    // Méthode utilitaire pour exécuter une transaction
    private void executeTransaction(Runnable action) {
        em.getTransaction().begin();
        try {
            action.run();
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
            throw new RuntimeException("Transaction échouée : " + e.getMessage());
        }
    }

    // Fermer l'EntityManager
    public void close() {
        if (em != null && em.isOpen()) {
            em.close();
        }
    }

    public Utilisateur verifierIdentifiants(String username, String password) {
        try {
            // Requête JPQL pour récupérer l'utilisateur avec le nom d'utilisateur et le mot de passe
            String jpql = "SELECT u FROM Utilisateur u WHERE u.nomUtilisateur = :username AND u.motDePasse = :password";
            TypedQuery<Utilisateur> query = em.createQuery(jpql, Utilisateur.class);
            query.setParameter("username", username);
            query.setParameter("password", password);

            // Retourner le premier utilisateur trouvé (ou null si non trouvé)
            return query.getResultStream().findFirst().orElse(null);
        } catch (Exception e) {
            // Gestion des erreurs et des exceptions
            e.printStackTrace();
            return null;
        }
    }






    private Connection getConnection() {
        // Retourne la connexion à votre base de données
        // Exemple (assurez-vous que la méthode de connexion est correctement définie dans votre DAO)
        // return DriverManager.getConnection(URL, USERNAME, PASSWORD);
        return null; // Remplacez ceci par la méthode réelle
    }




    public boolean mettreAJourUtilisateur(String nomUtilisateur, String nouvelleAutorisation) {
        // Trouver l'utilisateur par son nom d'utilisateur
        Utilisateur utilisateur = trouverParNomUtilisateur(nomUtilisateur);

        if (utilisateur != null) {
            // Démarrer la transaction
            executeTransaction(() -> {
                // Mettre à jour l'autorisation de l'utilisateur
                utilisateur.setAutorisation(nouvelleAutorisation);
            });
            return true; // Mise à jour réussie
        }

        return false; // L'utilisateur n'a pas été trouvé
    }
    public boolean ajouterUtilisateur(Utilisateur utilisateur) {
        // Ajoutez le code pour insérer un nouvel utilisateur dans votre base de données
        // Exemple avec une requête SQL
        String sql = "INSERT INTO utilisateurs (nomUtilisateur, motDePasse, autorisation, adresse, email, numeroTelephone) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, utilisateur.getNomUtilisateur());
            stmt.setString(2, utilisateur.getMotDePasse());
            stmt.setString(3, utilisateur.getAutorisation());
            stmt.setString(4, utilisateur.getAdresse());
            stmt.setString(5, utilisateur.getEmail());
            stmt.setString(6, utilisateur.getNumeroTelephone());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean supprimerUtilisateur(String nomUtilisateur) {
        // Ajoutez le code pour supprimer un utilisateur de votre base de données
        String sql = "DELETE FROM utilisateurs WHERE nomUtilisateur = ?";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nomUtilisateur);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    }
