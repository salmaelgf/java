package DAO;

import Models.Donateur;

import java.util.List;

public interface DonateurService {
    void ajouterDonateur(Donateur donateur);
    Donateur consulterDonateur(String id);
    void modifierDonateur(Donateur donateur);
    void supprimerDonateur(Donateur donateur);
    List<Donateur> listerTousDonateurs();
}
