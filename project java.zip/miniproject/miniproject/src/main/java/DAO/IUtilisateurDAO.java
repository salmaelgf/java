package DAO;

import Models.Utilisateur;

import java.util.List;

public interface IUtilisateurDAO {
    void ajouter(Utilisateur utilisateur);
    Utilisateur trouverParNomUtilisateur(String nomUtilisateur);
    boolean existeParNomUtilisateur(String nomUtilisateur);
    boolean supprimerParNomUtilisateur(String nomUtilisateur);
    boolean supprimerParId(String id);
    boolean modifierUtilisateur(String id, String nouveauNomUtilisateur, String nouveauMotDePasse, String nouveauRole,String nouvelleAdresse, String nouvelEmail, String nouveauNumeroTelephone);
    List<Utilisateur> listerTous();
}