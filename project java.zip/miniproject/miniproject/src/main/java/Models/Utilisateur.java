package Models;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;

@Entity
@Table(name = "utilisateur")
@lombok.Data
@AllArgsConstructor

public class Utilisateur {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nomUtilisateur;

    private String motDePasse;
    private String autorisation;
    private String adresse;
    private String email;
    private String numeroTelephone;

    // Constructeurs
    public Utilisateur() {}

    public Utilisateur( String nomUtilisateur, String motDePasse, String autorisation, String adresse, String email, String numeroTelephone) {

        this.nomUtilisateur = nomUtilisateur;
        this.motDePasse = motDePasse;
        this.autorisation = autorisation;
        this.adresse = adresse;
        this.email = email;
        this.numeroTelephone = numeroTelephone;
    }

    public Utilisateur(String nomUtilisateur, String motDePasse, String role) {
        this.nomUtilisateur = nomUtilisateur;
        this.motDePasse = motDePasse;
        this.autorisation = role;
    }

    public Utilisateur(String nomUtilisateur, String motDePasse) {
        this.nomUtilisateur = nomUtilisateur;
        this.motDePasse = motDePasse;
    }

    public Utilisateur(String nomUtilisateur, String motDePasse, String adresse, String email, String numeroTelephone) {
        this.nomUtilisateur = nomUtilisateur;
        this.motDePasse = motDePasse;
        this.adresse = adresse;
        this.email = email;
        this.numeroTelephone = numeroTelephone;
    }



    // Getters et Setters


    public String getNomUtilisateur() { return nomUtilisateur; }
    public void setNomUtilisateur(String nomUtilisateur) { this.nomUtilisateur = nomUtilisateur; }

    public String getMotDePasse() { return motDePasse; }
    public void setMotDePasse(String motDePasse) { this.motDePasse = motDePasse; }

    public String getAutorisation() { return autorisation; }
    public void setAutorisation(String autorisation) { this.autorisation = autorisation; }

    public String getAdresse() { return adresse; }
    public void setAdresse(String adresse) { this.adresse = adresse; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getNumeroTelephone() { return numeroTelephone; }
    public void setNumeroTelephone(String numeroTelephone) { this.numeroTelephone = numeroTelephone; }

    public void setRole(String nouveauRole) {
        this.autorisation = nouveauRole;
    }


}
