package Models;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class Demande {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String email;

    @Column(nullable = false)
    private String etat;

    @Column(nullable = false)
    private LocalDate dateCreation;

    @Column(nullable = false)
    private String nomBeneficier;

    @Column(nullable = false)
    private String emailBeneficier;

    @Column(nullable = false)
    private String telephoneBeneficier;

    // Default constructor
    public Demande() {
        this.dateCreation = LocalDate.now();
        this.etat = "EN_ATTENTE";
    }

    // Constructor with parameters
    public Demande(String email, String nomBeneficier, String emailBeneficier, String telephoneBeneficier) {
        this();
        this.email = email;
        this.nomBeneficier = nomBeneficier;
        this.emailBeneficier = emailBeneficier;
        this.telephoneBeneficier = telephoneBeneficier;
    }

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEtat() {
        return etat;
    }

    public void setEtat(String etat) {
        this.etat = etat;
    }

    public LocalDate getDateCreation() {
        return dateCreation;
    }

    public void setDateCreation(LocalDate dateCreation) {
        this.dateCreation = dateCreation;
    }

    public String getNomBeneficier() {
        return nomBeneficier;
    }

    public void setNomBeneficier(String nomBeneficier) {
        this.nomBeneficier = nomBeneficier;
    }

    public String getEmailBeneficier() {
        return emailBeneficier;
    }

    public void setEmailBeneficier(String emailBeneficier) {
        this.emailBeneficier = emailBeneficier;
    }

    public String getTelephoneBeneficier() {
        return telephoneBeneficier;
    }

    public void setTelephoneBeneficier(String telephoneBeneficier) {
        this.telephoneBeneficier = telephoneBeneficier;
    }

    public void setStatut(String nouveauStatut) {
    }
}