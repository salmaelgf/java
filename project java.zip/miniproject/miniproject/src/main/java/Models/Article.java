package Models;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "article")
public class Article {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)  // Ensure this is set for auto-generation of ID
    @Column(name = "ARTICLE_ID")
    private Integer articleId;

    @Column(name = "REFERENCE")
    private String reference;

    @Column(name = "DESCRIPTION")
    private String description;

    @Column(name = "ARTICLE_STATUS")
    private String articleStatus;

    @Column(name = "DONATION_DATE")
    @Temporal(TemporalType.DATE)
    private Date donationDate;

    @Column(name = "RECEIPT_QUANTITY")
    private String receiptQuantity;


    public Integer getArticleId() {
        return articleId;
    }

    public void setArticleId(Integer articleId) {
        this.articleId = articleId;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getArticleStatus() {
        return articleStatus;
    }

    public void setArticleStatus(String articleStatus) {
        this.articleStatus = articleStatus;
    }

    public Date getDonationDate() {
        return donationDate;
    }

    public void setDonationDate(Date donationDate) {
        this.donationDate = donationDate;
    }

    public String getReceiptQuantity() {
        return receiptQuantity;
    }

    public void setReceiptQuantity(String receiptQuantity) {
        this.receiptQuantity = receiptQuantity;
    }


}
