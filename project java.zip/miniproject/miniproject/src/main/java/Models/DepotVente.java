package Models;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.util.Date;

@Entity
@Table(name = "depot_ventes")
public class DepotVente {
    @Id
    private String id;
    private Date dateDepot;
    private String statut;
    private double prixEstime;
    private double prixVente;
    private Date dateVente;

    // Constructeurs
    public DepotVente() {}

    public DepotVente(String id, Date dateDepot, String statut, double prixEstime, double prixVente, Date dateVente) {
        this.id = id;
        this.dateDepot = dateDepot;
        this.statut = statut;
        this.prixEstime = prixEstime;
        this.prixVente = prixVente;
        this.dateVente = dateVente;
    }

    // Getters et Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public Date getDateDepot() { return dateDepot; }
    public void setDateDepot(Date dateDepot) { this.dateDepot = dateDepot; }
    public String getStatut() { return statut; }
    public void setStatut(String statut) { this.statut = statut; }
    public double getPrixEstime() { return prixEstime; }
    public void setPrixEstime(double prixEstime) { this.prixEstime = prixEstime; }
    public double getPrixVente() { return prixVente; }
    public void setPrixVente(double prixVente) { this.prixVente = prixVente; }
    public Date getDateVente() { return dateVente; }
    public void setDateVente(Date dateVente) { this.dateVente = dateVente; }
}
