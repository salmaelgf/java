package Models;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import java.time.LocalDate;

@Getter
@Entity
@Table(name = "donateur")
@AllArgsConstructor
@NoArgsConstructor
public class Donateur {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String email;

    @Column(nullable = false)
    private String tel;

    @Column(nullable = false)
    private String typeDon;

    @Column(nullable = false)
    private int quantite;

    @Column(nullable = false)
    private String description;

    @Column(nullable = false)
    private LocalDate dateCreation;

    // Constructor with parameters
    public Donateur(String name, String email, String tel, String typeDon, int quantite, String description) {
        this.name = name;
        this.email = email;
        this.tel = tel;
        this.typeDon = typeDon;
        this.quantite = quantite;
        this.description = description;
        this.dateCreation = LocalDate.now();
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public void setTypeDon(String typeDon) {
        this.typeDon = typeDon;
    }

    public void setQuantite(int quantite) {
        this.quantite = quantite;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDate getDateCreation() {
        return dateCreation;
    }

    public void setDateCreation(LocalDate dateCreation) {
        this.dateCreation = dateCreation;
    }
}